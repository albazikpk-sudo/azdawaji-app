# ازدواجی مسائل — Android App (APK / AAB)

کتاب کے تمام 68 صفحات ایپ کے اندر موجود ہیں (انٹرنیٹ کی ضرورت نہیں)۔

## خصوصیات
- صفحات پلٹنا: دائیں طرف سوائپ = اگلا صفحہ (اردو کتاب کی طرح) یا نیچے کے بٹن
- زوم: دو انگلیوں سے پنچ، یا ڈبل ٹیپ
- فہرست مضامین (34 عنوانات) اور صفحہ نمبر سے براہِ راست جانا
- بُک مارک (★) اور بُک مارکس کی فہرست
- نائٹ موڈ (🌙)
- آخری پڑھا ہوا صفحہ خود محفوظ ہوتا ہے

## بنانے کا طریقہ
**ضروری:** Android Studio (Koala یا نیا) اور JDK 17۔

1. Android Studio میں `File > Open` سے یہ فولڈر کھولیں اور Gradle Sync مکمل ہونے دیں (پہلی بار انٹرنیٹ چاہیے)۔
2. ٹیسٹ APK: `Build > Build Bundle(s) / APK(s) > Build APK(s)`
   فائل ملے گی: `app/build/outputs/apk/debug/app-debug.apk`

## Play Store کے لیے سائن شدہ AAB / APK
1. کلید بنائیں (ایک بار، اسے محفوظ رکھیں، کھو گئی تو ایپ اپڈیٹ نہیں ہو سکے گی):
   ```
   keytool -genkey -v -keystore azdawaji.jks -keyalg RSA -keysize 2048 -validity 10000 -alias azdawaji
   ```
2. فولڈر کی جڑ میں `keystore.properties` بنائیں:
   ```
   storeFile=azdawaji.jks
   storePassword=آپ کا پاس ورڈ
   keyAlias=azdawaji
   keyPassword=آپ کا پاس ورڈ
   ```
   (`azdawaji.jks` بھی اسی فولڈر میں رکھیں۔)
3. Android Studio میں `Build > Generate Signed App Bundle / APK`، یا ٹرمنل میں:
   - AAB: `gradlew bundleRelease` → `app/build/outputs/bundle/release/app-release.aab`
   - APK: `gradlew assembleRelease` → `app/build/outputs/apk/release/app-release.apk`

Play Store پر AAB اپلوڈ ہوتا ہے؛ APK براہِ راست شیئر کرنے کے لیے ہے۔

## تبدیلیاں
- ایپ کا نام: `app/src/main/res/values/strings.xml`
- پیکیج آئی ڈی: `app/build.gradle.kts` میں `applicationId` (Play Store پر شائع کرنے سے پہلے اپنی منفرد آئی ڈی رکھیں)
- ورژن بڑھانا: `versionCode` اور `versionName`
- آئیکن: `app/src/main/res/drawable/ic_launcher_*.xml` (اپنا ڈیزائن لگا سکتے ہیں)
- صفحات: `app/src/main/assets/pages/` میں تصاویر؛ فہرست `assets/index.html` کے `TOC` میں
